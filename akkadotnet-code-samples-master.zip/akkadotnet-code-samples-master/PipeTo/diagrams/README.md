# PipeTo Diagrams and Samples

Well, hello there! Interested in taking a look at some of the diagrams we used to illustrate how the [PipeTo Akka.NET sample](../) works?

We'll you're in luck! 

## Want to Use These Diagrams? You can!

Want to use any of these diagrams in your own post? Feel free. They're licensed under [Creative Commons Attribution 4.0 International](http://creativecommons.org/licenses/by/4.0/).

![Creative Commons Attribution 4.0 International License](../../images/creative-commons.png)

You should [read the text of the license](http://creativecommons.org/licenses/by/4.0/), but it basically means you can do whatever you want with these diagrams as long as you attribute [Petabridge](http://petabridge.com/ "Petabridge - Akka.NET training, support, and consulting") as the original authors.

## Modifying the Diagrams

All original diagram files are in `.sdr` format, which means they were made with [SmartDraw](http://www.smartdraw.com/ "SmartDraw - communicate visually with great diagrams for Windows").

![SmartDraw logo](../../images/smartdraw-logo.jpg)

You can [download a free trial of SmartDraw from their site](http://www.smartdraw.com/downloads/).