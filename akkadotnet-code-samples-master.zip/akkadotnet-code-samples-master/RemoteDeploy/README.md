# Akka.Remote Remote Deployment Sample

This code sample shows a couple of basic techniques for remotely deploying actors onto remote systems:

1. Remote deployment via procedural code (the `Props` API)
2. Remote deployment via HOCON.

