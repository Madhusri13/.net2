# Akka.Persistence AtLeastOnceDeliveryActor Sample

Demonstrates via a console application how `AtLeastOnceDeliveryActor` implementations will attempt to re-deliver messages to their intended recipient until they receive explicit acknowledgement that the message has been processed.